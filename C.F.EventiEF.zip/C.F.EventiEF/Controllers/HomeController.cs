using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using LazzeriniD_5I_EventiEF.Models;
using LazzeriniD_5I_EventiEF.Data;
using Microsoft.EntityFrameworkCore;

namespace LazzeriniD_5I_EventiEF.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
         //dbContext db = new dbContext();
         //db.Membri.Add(new Membro{Nickname="Cringino", Nome="Francesco", Cognome="Corbelli", Email="Francino@cringino.it"});
         //db.SaveChanges();

        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
