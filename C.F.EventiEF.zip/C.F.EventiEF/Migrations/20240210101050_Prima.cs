﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace C.F.Eventi.Migrations
{
    /// <inheritdoc />
    public partial class Prima : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categorie",
                columns: table => new
                {
                    Nome = table.Column<string>(type: "TEXT", nullable: false),
                    Descrizione = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categorie", x => x.Nome);
                });

            migrationBuilder.CreateTable(
                name: "Membri",
                columns: table => new
                {
                    Nickname = table.Column<string>(type: "TEXT", nullable: false),
                    Nome = table.Column<string>(type: "TEXT", nullable: true),
                    Cognome = table.Column<string>(type: "TEXT", nullable: true),
                    Email = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Membri", x => x.Nickname);
                });

            migrationBuilder.CreateTable(
                name: "TerritoriP",
                columns: table => new
                {
                    Nome = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TerritoriP", x => x.Nome);
                });

            migrationBuilder.CreateTable(
                name: "Posts",
                columns: table => new
                {
                    Commento = table.Column<string>(type: "TEXT", nullable: false),
                    Voto = table.Column<float>(type: "REAL", nullable: false),
                    Nickname = table.Column<string>(type: "TEXT", nullable: false),
                    MembroNickname = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Posts", x => x.Commento);
                    table.ForeignKey(
                        name: "FK_Posts_Membri_MembroNickname",
                        column: x => x.MembroNickname,
                        principalTable: "Membri",
                        principalColumn: "Nickname");
                });

            migrationBuilder.CreateTable(
                name: "Eventi",
                columns: table => new
                {
                    CodEvento = table.Column<string>(type: "TEXT", nullable: false),
                    Data = table.Column<DateTime>(type: "TEXT", nullable: false),
                    titolo = table.Column<string>(type: "TEXT", nullable: false),
                    Artisti = table.Column<string>(type: "TEXT", nullable: false),
                    Nickname = table.Column<string>(type: "TEXT", nullable: false),
                    MembroNickname = table.Column<string>(type: "TEXT", nullable: false),
                    NomeProvincia = table.Column<string>(type: "TEXT", nullable: false),
                    TerritorioPNome = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Eventi", x => x.CodEvento);
                    table.ForeignKey(
                        name: "FK_Eventi_Membri_MembroNickname",
                        column: x => x.MembroNickname,
                        principalTable: "Membri",
                        principalColumn: "Nickname",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Eventi_TerritoriP_TerritorioPNome",
                        column: x => x.TerritorioPNome,
                        principalTable: "TerritoriP",
                        principalColumn: "Nome",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Appertenenti",
                columns: table => new
                {
                    IdAppartenenza = table.Column<string>(type: "TEXT", nullable: true),
                    CodEvento = table.Column<string>(type: "TEXT", nullable: true),
                    EventoCodEvento = table.Column<string>(type: "TEXT", nullable: true),
                    Categorie = table.Column<string>(type: "TEXT", nullable: true),
                    CategoriaNome = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.ForeignKey(
                        name: "FK_Appertenenti_Categorie_CategoriaNome",
                        column: x => x.CategoriaNome,
                        principalTable: "Categorie",
                        principalColumn: "Nome");
                    table.ForeignKey(
                        name: "FK_Appertenenti_Eventi_EventoCodEvento",
                        column: x => x.EventoCodEvento,
                        principalTable: "Eventi",
                        principalColumn: "CodEvento");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Appertenenti_CategoriaNome",
                table: "Appertenenti",
                column: "CategoriaNome");

            migrationBuilder.CreateIndex(
                name: "IX_Appertenenti_EventoCodEvento",
                table: "Appertenenti",
                column: "EventoCodEvento");

            migrationBuilder.CreateIndex(
                name: "IX_Eventi_MembroNickname",
                table: "Eventi",
                column: "MembroNickname");

            migrationBuilder.CreateIndex(
                name: "IX_Eventi_TerritorioPNome",
                table: "Eventi",
                column: "TerritorioPNome");

            migrationBuilder.CreateIndex(
                name: "IX_Posts_MembroNickname",
                table: "Posts",
                column: "MembroNickname");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Appertenenti");

            migrationBuilder.DropTable(
                name: "Posts");

            migrationBuilder.DropTable(
                name: "Categorie");

            migrationBuilder.DropTable(
                name: "Eventi");

            migrationBuilder.DropTable(
                name: "Membri");

            migrationBuilder.DropTable(
                name: "TerritoriP");
        }
    }
}
