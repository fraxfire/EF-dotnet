using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
namespace LazzeriniD_5I_EventiEF.Data;

public class Categoria {
    [Key]
    public string Nome { get; set; }
    public string Descrizione { get; set; }

    public void OnModelCreating(ModelBuilder modelBuilder)
    {
    modelBuilder.Entity<Categoria>()
        .HasNoKey();
    }
}