using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
namespace LazzeriniD_5I_EventiEF.Data;

public class Membro
{
    [Key]
    public string? Nickname { get; set; }
    public string? Nome { get; set; }
    public string? Cognome { get; set; }
    public string? Email { get; set; }

    public void OnModelCreating(ModelBuilder modelBuilder)
    {
    modelBuilder.Entity<Membro>()
        .HasKey(Nickname);
    }
}