using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
namespace LazzeriniD_5I_EventiEF.Data;

public class TerritorioP{
    [Key]
    public string Nome { get; set; }

    public void OnModelCreating(ModelBuilder modelBuilder)
    {
    modelBuilder.Entity<TerritorioP>()
        .HasKey(Nome);
    }
}