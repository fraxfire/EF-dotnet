using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
namespace LazzeriniD_5I_EventiEF.Data;

public class Appartenente {
    [Key]
    public string IdAppartenenza { get; set; }
    public string? CodEvento { get; set; }
    public Evento? Evento { get; set; }
    public string? Categorie { get; set; }
    public Categoria? Categoria { get; set; }

    public void OnModelCreating(ModelBuilder modelBuilder)
    {
    modelBuilder.Entity<Appartenente>()
        .HasKey(IdAppartenenza);
    }

}
