using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
namespace LazzeriniD_5I_EventiEF.Data;

public class Post{
    [Key]
    public string Commento { get; set; }
    public float Voto { get; set; }
    public string Nickname { get; set; }
    public Membro Membro { get; set; }

    public void OnModelCreating(ModelBuilder modelBuilder)
    {
    modelBuilder.Entity<Post>()
        .HasNoKey();
    }
}