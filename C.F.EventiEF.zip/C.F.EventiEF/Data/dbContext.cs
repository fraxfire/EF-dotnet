using Microsoft.EntityFrameworkCore;
using LazzeriniD_5I_EventiEF.Data;
using Microsoft.AspNetCore.Mvc;


public class dbContext : DbContext
{
    protected override void OnConfiguring(DbContextOptionsBuilder options)
     => options.UseSqlite(@"Data Source=Data/Eventi.db");
     
    public DbSet<Membro> Membri { get; set; }
    public DbSet<Post> Posts { get; set; }
    public DbSet<Evento> Eventi { get; set; }
    public DbSet<TerritorioP> TerritoriP { get; set; }
    public DbSet<Categoria> Categorie { get; set; }
    public DbSet<Appartenente> Appertenenti { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Appartenente>().HasNoKey();
    }
    
}